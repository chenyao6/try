﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class guaiwu : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if(gameObject.transform.position.x<-14.99f)
		{
        gameObject.transform.position=new Vector3(15.0f,Random.Range(-3.07f,2.43f),0);
		}
	}
}
