﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class jump : MonoBehaviour {
public float downspeed=10.0f;
public float upspeed=20.0f;

// Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	/*if(Input.GetKeyUp(KeyCode.A))
	{
     gameObject.transform.Rotate(new Vector3(180,0,0));
    
	
	}*/
	 gameObject.transform.Translate(Vector2.down*downspeed*Time.deltaTime);
	if(Input.GetKeyUp(KeyCode.J))
	{
    gameObject.transform.Translate(Vector2.up*upspeed*Time.deltaTime);
//	GameObject go=Instantiate(prefabs fish,new Vector3(0,0,0),new Vector3(0,0,0));
	}
	}
	void OnCollisionEnter2D(Collision2D col) {
		if(col.collider.gameObject.name=="zhuzi")
		{
         Application.LoadLevel("2");
		}
	}
}
